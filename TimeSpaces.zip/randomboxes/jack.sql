INSERT INTO [OpenNos].[dbo].[RollGeneratedItem] (
	[OriginalItemDesign],
	[OriginalItemVNum],
	[Probability],
	[ItemGeneratedAmount],
	[ItemGeneratedVNum],
	[IsRareRandom],
	[MinimumOriginalItemRare],
	[MaximumOriginalItemRare],
	[IsSuperReward],
	[ItemGeneratedUpgrade]
)
VALUES
	(3, 302, 10, 1, 316, 1, 0, 7,0, 0),
	(3, 302, 10, 1, 319, 1, 0, 7,0, 0),
	(3, 302, 10, 1, 141, 1, 0, 7,0, 0),
	(3, 302, 10, 1, 148, 1, 0, 7,0, 0),
	(3, 302, 10, 1, 155, 1, 0, 7,0, 0),
	(3, 302, 7, 1, 292, 1, 0, 7,0, 0),
	(3, 302, 7, 1, 290, 1, 0, 7,0, 0),
	(3, 302, 7, 1, 294, 1, 0, 7,0, 0),
	(3, 302, 7, 1, 298, 1, 0, 7,0, 0),
	(3, 302, 7, 1, 296, 1, 0, 7,0, 0),
	(3, 302, 6, 1, 272, 1, 0, 7,0, 0),
	(0, 302, 3, 1, 910, 1, 0, 7,0, 0),
	(0, 302, 3, 1, 912, 1, 0, 7,0, 0),
	(0, 302, 3, 1, 914, 1, 0, 7,0, 0);