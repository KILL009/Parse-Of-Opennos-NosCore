INSERT INTO [OpenNos].[dbo].[RollGeneratedItem] (
	[OriginalItemDesign],
	[OriginalItemVNum],
	[Probability],
	[ItemGeneratedAmount],
	[ItemGeneratedVNum],
	[IsRareRandom],
	[MinimumOriginalItemRare],
	[MaximumOriginalItemRare],
	[IsSuperReward],
	[ItemGeneratedUpgrade]
)
VALUES
	(17, 302, 3, 1, 4497, 1, 0, 7,0, 0),
	(17, 302, 3, 1, 4498, 1, 0, 7,0, 0),
	(17, 302, 3, 1, 4499, 1, 0, 7,0, 0),
	(17, 302, 16, 1, 2519, 1, 0, 7,0, 0),
	(17, 302, 15, 1, 2518, 1, 0, 7,0, 0),
	(17, 302, 10, 5, 2282, 1, 0, 7,0, 0),
	(17, 302, 10, 5, 1030, 1, 0, 7,0, 0),
	(17, 302, 10, 3, 2349, 1, 0, 7, 0, 0),
	(17, 302, 10, 10, 2511, 1, 0, 7, 0, 0),
	(17, 302, 10, 10, 2512, 1, 0, 7, 0, 0),
	(17, 302, 10, 10, 2513, 1, 0, 7, 0, 0);
