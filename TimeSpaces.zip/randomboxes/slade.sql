INSERT INTO [OpenNos].[dbo].[RollGeneratedItem] (
	[OriginalItemDesign],
	[OriginalItemVNum],
	[Probability],
	[ItemGeneratedAmount],
	[ItemGeneratedVNum],
	[IsRareRandom],
	[MinimumOriginalItemRare],
	[MaximumOriginalItemRare],
	[IsSuperReward],
	[ItemGeneratedUpgrade]
)
VALUES
	(4, 302, 13, 1, 322, 1, 0, 7,0, 0),
	(4, 302, 12, 1, 317, 1, 0, 7,0, 0),
	(4, 302, 25, 1, 264, 1, 0, 7,0, 0),
	(4, 302, 25, 1, 267, 1, 0, 7,0, 0),
	(4, 302, 25, 1, 270, 1, 0, 7,0, 0);