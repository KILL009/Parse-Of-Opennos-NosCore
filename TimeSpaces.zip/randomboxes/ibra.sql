INSERT INTO [OpenNos].[dbo].[RollGeneratedItem] (
	[OriginalItemDesign],
	[OriginalItemVNum],
	[Probability],
	[ItemGeneratedAmount],
	[ItemGeneratedVNum],
	[IsRareRandom],
	[MinimumOriginalItemRare],
	[MaximumOriginalItemRare],
	[IsSuperReward],
	[ItemGeneratedUpgrade]
)
VALUES
	(9, 302, 6, 1, 4001, 1, 0, 7,0, 0),
	(9, 302, 6, 1, 4003, 1, 0, 7,0, 0),
	(9, 302, 6, 1, 4005, 1, 0, 7,0, 0),
	(9, 302, 5, 1, 4007, 1, 0, 7,0, 0),
	(9, 302, 5, 1, 4009, 1, 0, 7,0, 0),
	(9, 302, 5, 1, 4011, 1, 0, 7,0, 0),
	(9, 302, 6, 1, 4013, 1, 0, 7,0, 0),
	(9, 302, 6, 1, 4016, 1, 0, 7,0, 0),
	(9, 302, 6, 1, 4019, 1, 0, 7,0, 0),
	(9, 302, 30, 1, 1873, 1, 0, 7, 0, 0),
	(9, 302, 14, 2, 1873, 1, 0, 7,0, 0),
	(9, 302, 5, 3, 1873, 1, 0, 7, 0, 0);