INSERT INTO [OpenNos].[dbo].[RollGeneratedItem] (
	[OriginalItemDesign],
	[OriginalItemVNum],
	[Probability],
	[ItemGeneratedAmount],
	[ItemGeneratedVNum],
	[IsRareRandom],
	[MinimumOriginalItemRare],
	[MaximumOriginalItemRare],
	[IsSuperReward],
	[ItemGeneratedUpgrade]
)
VALUES
	(13, 302, 10, 7, 2900, 1, 0, 7, 0, 0),
	(13, 302, 5, 2, 2901, 1, 0, 7, 0, 0),
	(13, 302, 2, 5, 2901, 1, 0, 7, 0, 0),
	(13, 302, 1, 10, 2901, 1, 0, 7, 0, 0),
	(13, 302, 10, 3, 2503, 1, 0, 7, 0, 0),
	(13, 302, 10, 1, 2504, 1, 0, 7, 0, 0),
	(13, 302, 10, 1, 2506, 1, 0, 7, 0, 0),
	(13, 302, 9, 1, 5917, 1, 0, 7, 0, 0),
	(13, 302, 5, 1, 4911, 1, 0, 7, 0, 10),
	(13, 302, 9, 1, 4909, 1, 0, 7, 0, 0),
	(13, 302, 5, 1, 4914, 1, 0, 7, 0, 10),
	(13, 302, 9, 1, 4912, 1, 0, 7, 0, 0),
	(13, 302, 5, 1, 4917, 1, 0, 7, 0, 10),
	(13, 302, 9, 1, 4915, 1, 0, 7, 0, 0),
	(13, 302, 7, 1, 4934, 0, 0, 0, 0, 0),
	(13, 302, 1, 1, 2501, 1, 0, 7, 0, 0);