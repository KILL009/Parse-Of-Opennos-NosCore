INSERT INTO [OpenNos].[dbo].[RollGeneratedItem] (
	[OriginalItemDesign],
	[OriginalItemVNum],
	[Probability],
	[ItemGeneratedAmount],
	[ItemGeneratedVNum],
	[IsRareRandom],
	[MinimumOriginalItemRare],
	[MaximumOriginalItemRare],
	[IsSuperReward],
	[ItemGeneratedUpgrade]
)
VALUES
	(14, 302, 10, 7, 2900, 1, 0, 7, 0, 0),
	(14, 302, 5, 2, 2901, 1, 0, 7, 0, 0),
	(14, 302, 2, 5, 2901, 1, 0, 7, 0, 0),
	(14, 302, 1, 10, 2901, 1, 0, 7, 0, 0),
	(14, 302, 10, 3, 2503, 1, 0, 7, 0, 0),
	(14, 302, 10, 1, 2504, 1, 0, 7, 0, 0),
	(14, 302, 10, 1, 2506, 1, 0, 7, 0, 0),
	(14, 302, 9, 1, 5918, 1, 0, 7, 0, 0),
	(14, 302, 5, 1, 4920, 1, 0, 7, 0, 10),
	(14, 302, 9, 1, 4921, 1, 0, 7, 0, 0),
	(14, 302, 5, 1, 4923, 1, 0, 7, 0, 10),
	(14, 302, 9, 1, 4918, 1, 0, 7, 0, 0),
	(14, 302, 5, 1, 4926, 1, 0, 7, 0, 10),
	(14, 302, 9, 1, 4924, 1, 0, 7, 0, 0),
	(14, 302, 7, 1, 4932, 0, 0, 0, 0, 0),
	(14, 302, 1, 1, 2502, 1, 0, 7, 0, 0);