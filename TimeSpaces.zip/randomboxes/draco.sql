INSERT INTO [OpenNos].[dbo].[RollGeneratedItem] (
	[OriginalItemDesign],
	[OriginalItemVNum],
	[Probability],
	[ItemGeneratedAmount],
	[ItemGeneratedVNum],
	[IsRareRandom],
	[MinimumOriginalItemRare],
	[MaximumOriginalItemRare],
	[IsSuperReward],
	[ItemGeneratedUpgrade]
)
VALUES
	(16, 302, 3, 1, 4500, 1, 0, 7,0,0),
	(16, 302, 3, 1, 4501, 1, 0, 7,0,0),
	(16, 302, 3, 1, 4502, 1, 0, 7,0,0),
	(16, 302, 16, 1, 2519, 1, 0, 7,0,0),
	(16, 302, 10, 1, 2518, 1, 0, 7,0,0),
	(16, 302, 10, 5, 2282, 1, 0, 7,0,0),
	(16, 302, 10, 5, 1030, 1, 0, 7,0,0),
	(16, 302, 10, 3, 2349, 1, 0, 7, 0,0),
	(16, 302, 10, 10, 2511, 1, 0, 7, 0, 0),
	(16, 302, 10, 10, 2512, 1, 0, 7, 0, 0),
	(16, 302, 10, 10, 2513, 1, 0, 7, 0, 0);
